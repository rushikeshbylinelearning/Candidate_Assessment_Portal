import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, Zap, List, ChevronRight, ClipboardList, Clock, Users, CheckCircle, XCircle } from 'lucide-react';
import api from '../../utils/api';

export default function CreateAssessment() {
  const navigate = useNavigate();
  const [assessments, setAssessments] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api.get('/assessments')
      .then(res => setAssessments(res.data))
      .catch(() => {})
      .finally(() => setLoading(false));
  }, []);

  const modes = [
    {
      key: 'adaptive',
      icon: Zap,
      iconBg: '#eff6ff',
      iconColor: '#2563eb',
      title: 'Adaptive Mode',
      subtitle: 'Dynamic question selection',
      description:
        'Questions are selected dynamically based on candidate responses. The difficulty adjusts automatically to match the candidate\'s performance level.',
      cta: 'Select Adaptive Mode',
      path: '/hr/assessments/create/adaptive',
    },
    {
      key: 'standard',
      icon: List,
      iconBg: '#f0fdf4',
      iconColor: '#16a34a',
      title: 'Standard Mode',
      subtitle: 'Pre-selected questions',
      description:
        'Questions are pre-selected from the question bank. All candidates receive the same set of questions in a fixed order.',
      cta: 'Select Standard Mode',
      path: '/hr/assessments/create/standard',
    },
  ];

  return (
    <div>
      <button
        onClick={() => navigate('/hr/questions')}
        style={{ display: 'flex', alignItems: 'center', gap: 8, color: '#64748b', background: 'none', border: 'none', cursor: 'pointer', fontSize: 14, marginBottom: 28 }}
      >
        <ArrowLeft size={16} /> Back to Question Bank
      </button>

      <div style={{ maxWidth: 860, margin: '0 auto' }}>
        <div style={{ marginBottom: 32 }}>
          <h1 style={{ fontSize: 28, fontWeight: 800, color: '#0f172a' }}>Create New Assessment</h1>
          <p style={{ color: '#64748b', marginTop: 6, fontSize: 15 }}>Select the assessment mode to continue</p>
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 20 }}>
          {modes.map(mode => {
            const Icon = mode.icon;
            return (
              <div
                key={mode.key}
                style={{
                  background: '#fff',
                  borderRadius: 16,
                  border: '1px solid #e2e8f0',
                  padding: 28,
                  boxShadow: '0 1px 3px rgba(0,0,0,0.06)',
                  cursor: 'pointer',
                  transition: 'all 0.2s',
                }}
                onMouseEnter={e => {
                  e.currentTarget.style.boxShadow = '0 8px 24px rgba(0,0,0,0.1)';
                  e.currentTarget.style.borderColor = '#cbd5e1';
                  e.currentTarget.style.transform = 'translateY(-2px)';
                }}
                onMouseLeave={e => {
                  e.currentTarget.style.boxShadow = '0 1px 3px rgba(0,0,0,0.06)';
                  e.currentTarget.style.borderColor = '#e2e8f0';
                  e.currentTarget.style.transform = 'translateY(0)';
                }}
                onClick={() => navigate(mode.path)}
              >
                {/* Icon + title */}
                <div style={{ display: 'flex', alignItems: 'center', gap: 14, marginBottom: 16 }}>
                  <div style={{ width: 48, height: 48, borderRadius: 12, background: mode.iconBg, display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
                    <Icon size={24} color={mode.iconColor} />
                  </div>
                  <div>
                    <div style={{ fontSize: 17, fontWeight: 700, color: '#0f172a' }}>{mode.title}</div>
                    <div style={{ fontSize: 13, color: '#94a3b8', marginTop: 2 }}>{mode.subtitle}</div>
                  </div>
                </div>

                {/* Description */}
                <p style={{ fontSize: 14, color: '#475569', lineHeight: 1.7, marginBottom: 20 }}>
                  {mode.description}
                </p>

                {/* CTA */}
                <div style={{ display: 'flex', alignItems: 'center', gap: 6, color: mode.iconColor, fontWeight: 700, fontSize: 14 }}>
                  {mode.cta} <ChevronRight size={16} />
                </div>
              </div>
            );
          })}
        </div>

        {/* Created Assessments */}
        <div style={{ marginTop: 48 }}>
          <h2 style={{ fontSize: 20, fontWeight: 700, color: '#0f172a', marginBottom: 16 }}>Created Assessments</h2>

          {loading ? (
            <div style={{ textAlign: 'center', padding: '40px 0', color: '#94a3b8', fontSize: 14 }}>Loading assessments...</div>
          ) : assessments.length === 0 ? (
            <div style={{ textAlign: 'center', padding: '48px 0', background: '#fff', borderRadius: 16, border: '1px dashed #e2e8f0' }}>
              <ClipboardList size={36} color="#cbd5e1" style={{ margin: '0 auto 12px' }} />
              <p style={{ color: '#94a3b8', fontSize: 14 }}>No assessments created yet</p>
            </div>
          ) : (
            <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
              {assessments.map(a => (
                <div
                  key={a._id}
                  style={{
                    background: '#fff',
                    border: '1px solid #e2e8f0',
                    borderRadius: 12,
                    padding: '16px 20px',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'space-between',
                    boxShadow: '0 1px 3px rgba(0,0,0,0.05)',
                    cursor: 'pointer',
                    transition: 'box-shadow 0.2s',
                  }}
                  onMouseEnter={e => e.currentTarget.style.boxShadow = '0 4px 12px rgba(0,0,0,0.08)'}
                  onMouseLeave={e => e.currentTarget.style.boxShadow = '0 1px 3px rgba(0,0,0,0.05)'}
                  onClick={() => navigate(`/hr/assessments/${a._id}`)}
                >
                  <div style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
                    <div style={{ width: 40, height: 40, borderRadius: 10, background: '#eff6ff', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
                      <ClipboardList size={20} color="#2563eb" />
                    </div>
                    <div>
                      <div style={{ fontSize: 15, fontWeight: 600, color: '#0f172a' }}>{a.title}</div>
                      <div style={{ fontSize: 13, color: '#94a3b8', marginTop: 2 }}>
                        {a.roleId?.title || 'No role'}{a.roleId?.department ? ` · ${a.roleId.department}` : ''}
                      </div>
                    </div>
                  </div>

                  <div style={{ display: 'flex', alignItems: 'center', gap: 24 }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 6, color: '#64748b', fontSize: 13 }}>
                      <Clock size={14} /> {a.duration} min
                    </div>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 6, color: '#64748b', fontSize: 13 }}>
                      <Users size={14} /> {a.totalQuestions} questions
                    </div>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 5, fontSize: 13, fontWeight: 600, color: a.active ? '#16a34a' : '#94a3b8' }}>
                      {a.active
                        ? <><CheckCircle size={14} /> Active</>
                        : <><XCircle size={14} /> Inactive</>}
                    </div>
                    <ChevronRight size={16} color="#cbd5e1" />
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

      </div>
    </div>
  );
}
