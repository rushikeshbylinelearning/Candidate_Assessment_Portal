import React, { useEffect, useState } from 'react';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, FunnelChart, Funnel, LabelList } from 'recharts';
import api from '../../utils/api';
import Card from '../../components/ui/Card';
import { BarChart3 } from 'lucide-react';
import '../../styles/Analytics.css';
import '../../styles/SquircleHeader.css';

const COLORS = ['#e11d48', '#2563eb', '#16a34a', '#d97706', '#7c3aed', '#0891b2'];

export default function Analytics() {
  const [overview, setOverview] = useState(null);
  const [funnel, setFunnel] = useState([]);
  const [performance, setPerformance] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    Promise.all([
      api.get('/analytics/overview'),
      api.get('/analytics/funnel'),
      api.get('/analytics/performance'),
    ]).then(([ov, fn, pf]) => {
      setOverview(ov.data);
      setFunnel(fn.data);
      setPerformance(pf.data);
    }).finally(() => setLoading(false));
  }, []);

  if (loading) return <div className="analytics-loading">Loading analytics...</div>;

  const perfData = performance ? Object.entries(performance).map(([k, v]) => ({ name: k.charAt(0).toUpperCase() + k.slice(1), value: v })) : [];
  const statusData = overview ? [
    { name: 'Pending', value: overview.pendingAssessments },
    { name: 'Completed', value: overview.completedAssessments },
    { name: 'Shortlisted', value: overview.shortlisted },
    { name: 'Hired', value: overview.hired },
    { name: 'Rejected', value: overview.rejected },
  ] : [];

  const insights = [];
  if (overview?.passRate < 40) insights.push({ type: 'warning', text: 'Low pass rate detected — assessment may be too difficult or candidates need better screening.' });
  if (performance?.technical < 50) insights.push({ type: 'danger', text: 'Candidates are scoring low on technical questions — consider reviewing question difficulty.' });
  if (performance?.communication > performance?.technical) insights.push({ type: 'info', text: 'Candidates are stronger in communication than technical skills.' });
  if (overview?.completedAssessments > 0 && overview?.shortlisted / overview?.completedAssessments < 0.2) insights.push({ type: 'warning', text: 'Low shortlisting rate — review assessment pass threshold.' });

  return (
    <div>
      {/* Squircle Header */}
      <div className="squircle-header">
        <div className="squircle-header-icon">
          <BarChart3 size={20} />
        </div>
        <div className="squircle-header-content">
          <h1>Analytics</h1>
          <p>Performance insights and trends</p>
        </div>
      </div>

      {/* KPI Row */}
      <div className="analytics-kpi-grid">
        {[
          ['Total Candidates', overview?.totalCandidates, '#e11d48'],
          ['Completed', overview?.completedAssessments, '#2563eb'],
          ['Pass Rate', `${overview?.passRate ?? 0}%`, '#16a34a'],
          ['Avg Score', `${overview?.averageScore ?? 0}%`, '#d97706'],
          ['Hired', overview?.hired, '#7c3aed'],
        ].map(([label, value, color]) => (
          <Card key={label} className="analytics-kpi-card">
            <div className="analytics-kpi-value" style={{ color }}>{value ?? '—'}</div>
            <div className="analytics-kpi-label">{label}</div>
          </Card>
        ))}
      </div>

      {/* Charts */}
      <div className="analytics-charts-grid">
        <Card>
          <h3 className="analytics-chart-title">Hiring Funnel</h3>
          <ResponsiveContainer width="100%" height={240}>
            <BarChart data={funnel} layout="vertical">
              <XAxis type="number" tick={{ fontSize: 12 }} />
              <YAxis dataKey="stage" type="category" tick={{ fontSize: 12 }} width={100} />
              <Tooltip />
              <Bar dataKey="count" fill="#e11d48" radius={[0, 4, 4, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </Card>

        <Card>
          <h3 className="analytics-chart-title">Candidate Status Distribution</h3>
          <ResponsiveContainer width="100%" height={240}>
            <PieChart>
              <Pie data={statusData} cx="50%" cy="50%" outerRadius={90} dataKey="value" label={({ name, value }) => `${name}: ${value}`} labelLine={false}>
                {statusData.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
              </Pie>
              <Tooltip />
            </PieChart>
          </ResponsiveContainer>
        </Card>
      </div>

      <Card style={{ marginBottom: 20 }}>
        <h3 className="analytics-chart-title">Average Score by Skill Category</h3>
        <ResponsiveContainer width="100%" height={200}>
          <BarChart data={perfData}>
            <XAxis dataKey="name" tick={{ fontSize: 13 }} />
            <YAxis domain={[0, 100]} tick={{ fontSize: 12 }} />
            <Tooltip formatter={v => `${v}%`} />
            <Bar dataKey="value" radius={[4, 4, 0, 0]}>
              {perfData.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
            </Bar>
          </BarChart>
        </ResponsiveContainer>
      </Card>

      {/* Insights */}
      {insights.length > 0 && (
        <Card>
          <h3 className="analytics-insights-title">AI-Ready Insights</h3>
          <div className="analytics-insights-list">
            {insights.map((ins, i) => (
              <div key={i} className={`analytics-insight-item ${ins.type}`}>
                {ins.text}
              </div>
            ))}
          </div>
        </Card>
      )}
    </div>
  );
}
