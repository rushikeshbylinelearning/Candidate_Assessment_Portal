import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import api from '../../utils/api';
import Button from '../../components/ui/Button';
import StructuredResume from '../../components/resume/StructuredResume';
import RoleMatchCard from '../../components/resume/RoleMatchCard';
import { 
  Mail, Phone, ChevronRight, ChevronDown, Calendar, Clock, CheckCircle2, XCircle,
  Edit2, Plus, X, Save, Trash2, MessageSquare, TrendingUp, TrendingDown, Sparkles
} from 'lucide-react';
import toast from 'react-hot-toast';
import '../../styles/CandidateDetail.css';

export default function CandidateDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [candidate, setCandidate] = useState(null);
  const [responses, setResponses] = useState([]);
  const [score, setScore] = useState(null);
  const [logs, setLogs] = useState([]);
  const [resumeData, setResumeData] = useState(null);
  const [roleMatch, setRoleMatch] = useState(null);
  const [showOriginalResume, setShowOriginalResume] = useState(false);
  const [logForm, setLogForm] = useState({ 
    round: '', 
    stage: 'technical', 
    notes: '', 
    rating: 7, 
    strengths: '', 
    weaknesses: '', 
    recommendation: 'proceed', 
    nextAction: '' 
  });
  const [showDrawer, setShowDrawer] = useState(false);
  const [loading, setLoading] = useState(true);
  const [expandedRounds, setExpandedRounds] = useState({});
  
  // Strength & Weakness Management
  const [strengths, setStrengths] = useState([
    'Strong problem-solving skills',
    'Excellent communication',
    'Quick learner'
  ]);
  const [weaknesses, setWeaknesses] = useState([
    'Limited system design experience',
    'Needs improvement in testing'
  ]);
  const [editingStrength, setEditingStrength] = useState(null);
  const [editingWeakness, setEditingWeakness] = useState(null);
  const [newStrength, setNewStrength] = useState('');
  const [newWeakness, setNewWeakness] = useState('');

  const fetchAll = async () => {
    const [c, r, s, l] = await Promise.all([
      api.get(`/candidates/${id}`),
      api.get(`/responses?candidateId=${id}`).catch(() => ({ data: [] })),
      api.get(`/responses/score/${id}`).catch(() => ({ data: null })),
      api.get(`/notes?candidateId=${id}`),
    ]);
    setCandidate(c.data);
    setResponses(r.data);
    setScore(s.data);
    setLogs(l.data);
    
    // Fetch resume data if resume exists
    if (c.data.resumeUrl) {
      try {
        const resumeRes = await api.get(`/resume/${id}`);
        setResumeData(resumeRes.data);
        
        // Fetch role match if role exists
        if (c.data.appliedRole?._id) {
          const matchRes = await api.get(`/resume/${id}/match/${c.data.appliedRole._id}`);
          setRoleMatch(matchRes.data);
        }
      } catch (err) {
        console.log('Resume data not available yet');
      }
    }
  };

  useEffect(() => { 
    fetchAll().finally(() => setLoading(false)); 
  }, [id]);

  const handleDecision = async (decision) => {
    await api.put(`/candidates/${id}/status`, { finalDecision: decision });
    toast.success(`Marked as ${decision}`);
    fetchAll();
  };

  const handleLogSubmit = async (e) => {
    e.preventDefault();
    try {
      await api.post('/notes', {
        ...logForm,
        candidateId: id,
        strengths: logForm.strengths.split(',').map(s => s.trim()).filter(Boolean),
        weaknesses: logForm.weaknesses.split(',').map(s => s.trim()).filter(Boolean),
        rating: parseInt(logForm.rating),
      });
      toast.success('Interview log saved');
      setShowDrawer(false);
      setLogForm({ 
        round: '', 
        stage: 'technical', 
        notes: '', 
        rating: 7, 
        strengths: '', 
        weaknesses: '', 
        recommendation: 'proceed', 
        nextAction: '' 
      });
      fetchAll();
    } catch {
      toast.error('Failed to save log');
    }
  };

  const toggleRound = (index) => {
    setExpandedRounds(prev => ({ ...prev, [index]: !prev[index] }));
  };

  // Strength & Weakness Handlers
  const addStrength = () => {
    if (newStrength.trim()) {
      setStrengths([...strengths, newStrength.trim()]);
      setNewStrength('');
    }
  };

  const addWeakness = () => {
    if (newWeakness.trim()) {
      setWeaknesses([...weaknesses, newWeakness.trim()]);
      setNewWeakness('');
    }
  };

  const updateStrength = (index, value) => {
    const updated = [...strengths];
    updated[index] = value;
    setStrengths(updated);
    setEditingStrength(null);
  };

  const updateWeakness = (index, value) => {
    const updated = [...weaknesses];
    updated[index] = value;
    setWeaknesses(updated);
    setEditingWeakness(null);
  };

  const deleteStrength = (index) => {
    setStrengths(strengths.filter((_, i) => i !== index));
  };

  const deleteWeakness = (index) => {
    setWeaknesses(weaknesses.filter((_, i) => i !== index));
  };

  const openNotesDrawer = () => {
    setShowDrawer(true);
    setLogForm({ 
      round: '', 
      stage: 'technical', 
      notes: '', 
      rating: 7, 
      strengths: '', 
      weaknesses: '', 
      recommendation: 'proceed', 
      nextAction: '' 
    });
  };

  if (loading) {
    return (
      <div className="candidate-detail-loading">
        <div className="shimmer-container">
          <div className="shimmer shimmer-hero"></div>
          <div className="shimmer-columns">
            <div className="shimmer shimmer-panel"></div>
            <div className="shimmer shimmer-panel"></div>
          </div>
        </div>
      </div>
    );
  }

  if (!candidate) {
    return (
      <div className="candidate-detail-error">
        <div className="error-content">
          <XCircle size={48} />
          <h2>Candidate not found</h2>
          <Button onClick={() => navigate('/hr/candidates')}>Back to Candidates</Button>
        </div>
      </div>
    );
  }

  // Derived score stats
  const weights = candidate.appliedRole?.scoringWeights || { 
    aptitude: 20, 
    technical: 50, 
    reasoning: 20, 
    communication: 10 
  };
  
  const totalEarned = responses.reduce((s, r) => s + (r.scoreAwarded || 0), 0);
  const totalPossible = responses.reduce((s, r) => s + (r.questionId?.points || 1), 0);
  const attempted = responses.filter(r => r.answer !== null && r.answer !== undefined && r.answer !== '').length;
  const correct = responses.filter(r => r.isCorrect === true).length;
  const autoScorable = responses.filter(r => r.isAutoScored).length;

  // Group responses by category for evaluation rounds
  const responsesByCategory = responses.reduce((acc, r) => {
    const cat = r.questionId?.category || 'general';
    if (!acc[cat]) acc[cat] = [];
    acc[cat].push(r);
    return acc;
  }, {});

  // Calculate category scores
  const categoryScores = Object.entries(responsesByCategory).map(([category, catResponses]) => {
    const catEarned = catResponses.reduce((s, r) => s + (r.scoreAwarded || 0), 0);
    const catPossible = catResponses.reduce((s, r) => s + (r.questionId?.points || 1), 0);
    const catScore = catPossible > 0 ? Math.round((catEarned / catPossible) * 100) : 0;
    const catCorrect = catResponses.filter(r => r.isCorrect === true).length;
    const catTime = catResponses.reduce((s, r) => s + (r.timeSpent || 0), 0);
    
    return {
      name: category.charAt(0).toUpperCase() + category.slice(1),
      score: catScore,
      earned: catEarned,
      possible: catPossible,
      questions: catResponses.length,
      correct: catCorrect,
      timeSpent: catTime,
      responses: catResponses
    };
  });

  // Status pill config
  const getStatusConfig = (status) => {
    const configs = {
      pending: { bg: '#FEF3C7', text: '#92400E', label: 'Pending' },
      shortlisted: { bg: '#D1FAE5', text: '#065F46', label: 'Shortlisted' },
      rejected: { bg: '#FEE2E2', text: '#991B1B', label: 'Rejected' },
      hired: { bg: '#DBEAFE', text: '#1E40AF', label: 'Hired' },
      completed: { bg: '#D1FAE5', text: '#065F46', label: 'Completed' },
      'in-progress': { bg: '#FEF3C7', text: '#92400E', label: 'In Progress' },
    };
    return configs[status?.toLowerCase()] || configs.pending;
  };

  const statusConfig = getStatusConfig(candidate.assessmentStatus);

  // Skill accent colors
  const skillColors = {
    aptitude: '#F43F5E',
    technical: '#3B82F6',
    reasoning: '#22C55E',
    communication: '#F59E0B',
  };

  return (
    <div className="candidate-detail-page">
      {/* Two Column Layout */}
      <div className="candidate-columns">
        {/* Left Column - Resume (Only if uploaded) */}
        {candidate.resumeUrl ? (
          <div className="column-left">
            <div className="resume-panel">
              {/* Show structured resume by default, original on toggle */}
              {showOriginalResume ? (
                <>
                  <div className="resume-header">
                    <h2 className="resume-name">{candidate.name}</h2>
                    <div className="resume-contact">
                      <span className="contact-item">
                        <Mail size={14} />
                        {candidate.email}
                      </span>
                      <span className="contact-separator">|</span>
                      <span className="contact-item">
                        <Phone size={14} />
                        {candidate.phone || '—'}
                      </span>
                    </div>
                    <div className="resume-tags">
                      <span className="resume-tag">{candidate.appliedRole?.title}</span>
                      <span className="resume-tag">{candidate.appliedRole?.department}</span>
                      <span className="resume-tag">{candidate.experienceLevel}</span>
                    </div>
                    <button 
                      onClick={() => setShowOriginalResume(false)} 
                      className="toggle-resume-btn"
                    >
                      View Structured Resume
                    </button>
                  </div>

                  {/* Resume Display */}
                  <div className="resume-viewer">
                    <iframe 
                      src={candidate.resumeUrl} 
                      title="Resume"
                      className="resume-iframe"
                    />
                  </div>
                </>
              ) : (
                <StructuredResume 
                  resumeData={resumeData}
                  candidate={candidate}
                  onViewOriginal={() => setShowOriginalResume(true)}
                />
              )}
            </div>
          </div>
        ) : null}

        {/* Right Column - Evaluation & Timeline */}
        <div className="column-right">
          <div className="evaluation-panel">
            {/* Role Match Card */}
            {roleMatch && <RoleMatchCard matchData={roleMatch} />}
            
            {/* Score Overview Cards */}
            {score && (
              <div className="score-overview">
                <div className="score-cards">
                  {Object.entries(score.sectionScores || {}).map(([category, percentage]) => (
                    <div 
                      key={category} 
                      className="score-card"
                      style={{ borderTopColor: skillColors[category] || '#94A3B8' }}
                    >
                      <div className="score-value">{percentage}</div>
                      <div className="score-label">{category.charAt(0).toUpperCase() + category.slice(1)}</div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Strength & Weakness Section */}
            <div className="strength-weakness-section">
              <div className="section-header">
                <h3 className="section-title">Strengths & Weaknesses</h3>
              </div>
              
              {/* Strengths Grid */}
              <div className="sw-grid">
                <div className="sw-label">
                  <TrendingUp size={14} />
                  <span>Strengths</span>
                </div>
                <div className="sw-items">
                  {strengths.map((strength, index) => (
                    <div key={index} className="sw-item strength-item">
                      {editingStrength === index ? (
                        <div className="sw-edit-mode">
                          <input
                            type="text"
                            value={strength}
                            onChange={(e) => {
                              const updated = [...strengths];
                              updated[index] = e.target.value;
                              setStrengths(updated);
                            }}
                            onKeyDown={(e) => {
                              if (e.key === 'Enter') updateStrength(index, strength);
                              if (e.key === 'Escape') setEditingStrength(null);
                            }}
                            autoFocus
                            className="sw-input"
                          />
                          <button 
                            onClick={() => updateStrength(index, strength)}
                            className="sw-btn save-btn"
                          >
                            <Save size={12} />
                          </button>
                          <button 
                            onClick={() => setEditingStrength(null)}
                            className="sw-btn cancel-btn"
                          >
                            <X size={12} />
                          </button>
                        </div>
                      ) : (
                        <>
                          <span className="sw-text">{strength}</span>
                          <div className="sw-actions">
                            <button 
                              onClick={() => setEditingStrength(index)}
                              className="sw-action-btn"
                            >
                              <Edit2 size={12} />
                            </button>
                            <button 
                              onClick={() => deleteStrength(index)}
                              className="sw-action-btn delete-btn"
                            >
                              <Trash2 size={12} />
                            </button>
                          </div>
                        </>
                      )}
                    </div>
                  ))}
                  <div className="sw-item add-item">
                    <input
                      type="text"
                      placeholder="Add strength..."
                      value={newStrength}
                      onChange={(e) => setNewStrength(e.target.value)}
                      onKeyDown={(e) => {
                        if (e.key === 'Enter') addStrength();
                      }}
                      className="sw-add-input"
                    />
                    <button onClick={addStrength} className="sw-add-btn">
                      <Plus size={14} />
                    </button>
                  </div>
                </div>
              </div>

              {/* Weaknesses Grid */}
              <div className="sw-grid">
                <div className="sw-label weakness-label">
                  <TrendingDown size={14} />
                  <span>Weaknesses</span>
                </div>
                <div className="sw-items">
                  {weaknesses.map((weakness, index) => (
                    <div key={index} className="sw-item weakness-item">
                      {editingWeakness === index ? (
                        <div className="sw-edit-mode">
                          <input
                            type="text"
                            value={weakness}
                            onChange={(e) => {
                              const updated = [...weaknesses];
                              updated[index] = e.target.value;
                              setWeaknesses(updated);
                            }}
                            onKeyDown={(e) => {
                              if (e.key === 'Enter') updateWeakness(index, weakness);
                              if (e.key === 'Escape') setEditingWeakness(null);
                            }}
                            autoFocus
                            className="sw-input"
                          />
                          <button 
                            onClick={() => updateWeakness(index, weakness)}
                            className="sw-btn save-btn"
                          >
                            <Save size={12} />
                          </button>
                          <button 
                            onClick={() => setEditingWeakness(null)}
                            className="sw-btn cancel-btn"
                          >
                            <X size={12} />
                          </button>
                        </div>
                      ) : (
                        <>
                          <span className="sw-text">{weakness}</span>
                          <div className="sw-actions">
                            <button 
                              onClick={() => setEditingWeakness(index)}
                              className="sw-action-btn"
                            >
                              <Edit2 size={12} />
                            </button>
                            <button 
                              onClick={() => deleteWeakness(index)}
                              className="sw-action-btn delete-btn"
                            >
                              <Trash2 size={12} />
                            </button>
                          </div>
                        </>
                      )}
                    </div>
                  ))}
                  <div className="sw-item add-item">
                    <input
                      type="text"
                      placeholder="Add weakness..."
                      value={newWeakness}
                      onChange={(e) => setNewWeakness(e.target.value)}
                      onKeyDown={(e) => {
                        if (e.key === 'Enter') addWeakness();
                      }}
                      className="sw-add-input"
                    />
                    <button onClick={addWeakness} className="sw-add-btn">
                      <Plus size={14} />
                    </button>
                  </div>
                </div>
              </div>
            </div>

            {/* Notes Section with Timeline */}
            <div className="notes-section">
              <div className="notes-header">
                <div className="notes-title-row">
                  <MessageSquare size={18} />
                  <h3 className="notes-title">Notes</h3>
                </div>
                <button 
                  className="add-note-btn"
                  onClick={openNotesDrawer}
                >
                  <Edit2 size={14} />
                  <span>Add Note</span>
                </button>
              </div>

              {logs.length === 0 ? (
                <div className="notes-empty">
                  <Calendar size={32} color="#94A3B8" />
                  <div className="empty-text">No notes yet</div>
                  <p className="empty-subtext">Add interview feedback and evaluation notes</p>
                </div>
              ) : (
                <div className="notes-timeline">
                  {logs.map((log, index) => (
                    <div key={log._id} className="note-item">
                      <div className="note-marker"></div>
                      <div className="note-content">
                        <div className="note-header">
                          <div className="note-title">
                            <span className="note-round">{log.round}</span>
                            <span 
                              className="note-stage"
                              style={{
                                background: log.stage === 'technical' ? '#EFF6FF' : 
                                           log.stage === 'hr' ? '#F0FDF4' : 
                                           log.stage === 'final' ? '#FEF3C7' : '#F3F4F6',
                                color: log.stage === 'technical' ? '#2563EB' : 
                                       log.stage === 'hr' ? '#16A34A' : 
                                       log.stage === 'final' ? '#D97706' : '#64748B'
                              }}
                            >
                              {log.stage}
                            </span>
                          </div>
                          <div className="note-meta">
                            <span className="note-rating">
                              <span className="rating-dot"></span>
                              {log.rating}/10
                            </span>
                            <span 
                              className="note-recommendation"
                              style={{
                                background: log.recommendation === 'proceed' ? '#D1FAE5' : 
                                           log.recommendation === 'reject' ? '#FEE2E2' : '#FEF3C7',
                                color: log.recommendation === 'proceed' ? '#065F46' : 
                                      log.recommendation === 'reject' ? '#991B1B' : '#92400E'
                              }}
                            >
                              {log.recommendation}
                            </span>
                          </div>
                        </div>
                        {log.notes && <p className="note-text">{log.notes}</p>}
                        {(log.strengths?.length > 0 || log.weaknesses?.length > 0) && (
                          <div className="note-feedback">
                            {log.strengths?.length > 0 && (
                              <div className="note-strengths">
                                <CheckCircle2 size={12} />
                                <span>{log.strengths.join(', ')}</span>
                              </div>
                            )}
                            {log.weaknesses?.length > 0 && (
                              <div className="note-weaknesses">
                                <XCircle size={12} />
                                <span>{log.weaknesses.join(', ')}</span>
                              </div>
                            )}
                          </div>
                        )}
                        <div className="note-footer">
                          <span className="note-author">
                            By {log.interviewerId?.name || 'Unknown'}
                          </span>
                          <span className="note-date">
                            {new Date(log.createdAt).toLocaleDateString('en-US', { 
                              month: 'short', 
                              day: 'numeric', 
                              year: 'numeric' 
                            })}
                          </span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Right Side Drawer for Adding Notes */}
      {showDrawer && (
        <>
          <div className="drawer-overlay" onClick={() => setShowDrawer(false)}></div>
          <div className="drawer-panel">
            <div className="drawer-header">
              <h2 className="drawer-title">Add Interview Note</h2>
              <button 
                className="drawer-close"
                onClick={() => setShowDrawer(false)}
              >
                <X size={20} />
              </button>
            </div>
            <form onSubmit={handleLogSubmit} className="drawer-form">
              <div className="form-field">
                <label className="form-label">Round Name</label>
                <input 
                  required 
                  value={logForm.round} 
                  onChange={e => setLogForm(p => ({ ...p, round: e.target.value }))} 
                  placeholder="e.g. Round 1 - Technical"
                  className="form-input"
                />
              </div>
              
              <div className="form-row">
                <div className="form-field">
                  <label className="form-label">Stage</label>
                  <select 
                    value={logForm.stage} 
                    onChange={e => setLogForm(p => ({ ...p, stage: e.target.value }))}
                    className="form-select"
                  >
                    {['screening', 'technical', 'hr', 'final', 'offer'].map(s => (
                      <option key={s} value={s}>{s}</option>
                    ))}
                  </select>
                </div>
                <div className="form-field">
                  <label className="form-label">Rating (1-10)</label>
                  <input 
                    type="number" 
                    min="1" 
                    max="10" 
                    value={logForm.rating} 
                    onChange={e => setLogForm(p => ({ ...p, rating: e.target.value }))}
                    className="form-input"
                  />
                </div>
              </div>

              <div className="form-field">
                <label className="form-label">Notes</label>
                <textarea 
                  value={logForm.notes} 
                  onChange={e => setLogForm(p => ({ ...p, notes: e.target.value }))} 
                  rows={4}
                  placeholder="Add detailed feedback..."
                  className="form-textarea"
                />
              </div>

              <div className="form-row">
                <div className="form-field">
                  <label className="form-label">Strengths (comma-separated)</label>
                  <input 
                    value={logForm.strengths} 
                    onChange={e => setLogForm(p => ({ ...p, strengths: e.target.value }))} 
                    placeholder="e.g. Problem solving, Communication"
                    className="form-input"
                  />
                </div>
                <div className="form-field">
                  <label className="form-label">Weaknesses</label>
                  <input 
                    value={logForm.weaknesses} 
                    onChange={e => setLogForm(p => ({ ...p, weaknesses: e.target.value }))} 
                    placeholder="e.g. System design"
                    className="form-input"
                  />
                </div>
              </div>

              <div className="form-row">
                <div className="form-field">
                  <label className="form-label">Recommendation</label>
                  <select 
                    value={logForm.recommendation} 
                    onChange={e => setLogForm(p => ({ ...p, recommendation: e.target.value }))}
                    className="form-select"
                  >
                    {['proceed', 'hold', 'reject', 'hire'].map(r => (
                      <option key={r} value={r}>{r}</option>
                    ))}
                  </select>
                </div>
                <div className="form-field">
                  <label className="form-label">Next Action</label>
                  <input 
                    value={logForm.nextAction} 
                    onChange={e => setLogForm(p => ({ ...p, nextAction: e.target.value }))} 
                    placeholder="e.g. Schedule final round"
                    className="form-input"
                  />
                </div>
              </div>

              <div className="drawer-actions">
                <Button type="submit" className="btn-submit">Save Note</Button>
                <Button variant="ghost" onClick={() => setShowDrawer(false)} type="button">Cancel</Button>
              </div>
            </form>
          </div>
        </>
      )}

      {/* Floating Action Button */}
      <button 
        className="fab-button"
        onClick={openNotesDrawer}
        title="Add Interview Note"
      >
        <Edit2 size={20} />
      </button>
    </div>
  );
}
