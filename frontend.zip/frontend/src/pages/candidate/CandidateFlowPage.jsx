import React, { useEffect, useState, useCallback } from 'react';
import { useParams } from 'react-router-dom';
import axios from 'axios';
import StepIndicator from '../../components/pipeline/StepIndicator';
import ProgressBar from '../../components/pipeline/ProgressBar';
import StepRenderer from '../../components/pipeline/StepRenderer';

export default function CandidateFlowPage() {
  const { token } = useParams();
  const [session, setSession] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [countdown, setCountdown] = useState(null);

  const initSession = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      localStorage.setItem('pipeline_token', token);

      const headers = { 'x-pipeline-token': token };

      // Initialize session
      const { data } = await axios.post('/api/pipeline/session', {}, { headers });
      const pipeline = data.pipeline || data;

      // If a step is already in progress, resume it
      if (pipeline._id && pipeline.currentStep && pipeline.stepStatus?.[pipeline.currentStep] === 'IN_PROGRESS') {
        const resumeRes = await axios.post(`/api/pipeline/${pipeline._id}/resume`, {}, { headers });
        setSession(resumeRes.data.pipeline || resumeRes.data);
      } else {
        setSession(pipeline);
      }
    } catch (err) {
      setError(err.response?.data?.message || 'Invalid or expired token.');
    } finally {
      setLoading(false);
    }
  }, [token]);

  useEffect(() => {
    if (token) initSession();
  }, [token, initSession]);

  // Countdown timer for steps with remainingTime (in minutes)
  useEffect(() => {
    if (!session?.remainingTime) {
      setCountdown(null);
      return;
    }

    let seconds = session.remainingTime * 60;
    setCountdown(seconds);

    const interval = setInterval(() => {
      seconds -= 1;
      setCountdown(seconds);
      if (seconds <= 0) clearInterval(interval);
    }, 1000);

    return () => clearInterval(interval);
  }, [session?.remainingTime, session?.currentStep]);

  const handleStepComplete = useCallback(async () => {
    await initSession();
  }, [initSession]);

  if (loading) {
    return (
      <div style={styles.center}>
        <div style={styles.spinner} />
        <p style={{ color: '#64748b', marginTop: 16 }}>Loading your pipeline...</p>
      </div>
    );
  }

  if (error) {
    return (
      <div style={styles.center}>
        <div style={{ fontSize: 48, marginBottom: 16 }}>🔒</div>
        <h2 style={{ color: '#0f172a', marginBottom: 8 }}>Access Denied</h2>
        <p style={{ color: '#64748b' }}>{error}</p>
      </div>
    );
  }

  const steps = session?.steps || [];
  const totalSteps = steps.length;
  const completedSteps = steps.filter(s => s.status === 'COMPLETED' || s.status === 'SKIPPED').length;
  const currentStepIndex = completedSteps + 1;

  return (
    <div style={styles.container}>
      <div style={styles.header}>
        <StepIndicator currentStepIndex={currentStepIndex} totalSteps={totalSteps} />
        {countdown !== null && (
          <div style={styles.timer}>
            ⏱ {Math.floor(countdown / 60)}:{String(countdown % 60).padStart(2, '0')}
          </div>
        )}
      </div>

      <div style={styles.progressWrap}>
        <ProgressBar completedSteps={completedSteps} totalSteps={totalSteps} />
      </div>

      <div style={styles.stepWrap}>
        <StepRenderer
          currentStep={session?.currentStep}
          pipelineId={session?._id}
          partialData={session?.partialData}
          remainingTime={session?.remainingTime}
          onStepComplete={handleStepComplete}
        />
      </div>
    </div>
  );
}

const styles = {
  container: {
    maxWidth: 720,
    margin: '0 auto',
    padding: '32px 16px',
  },
  header: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  progressWrap: {
    marginBottom: 32,
  },
  stepWrap: {
    background: '#fff',
    borderRadius: 12,
    boxShadow: '0 1px 4px rgba(0,0,0,0.08)',
    padding: 32,
  },
  timer: {
    fontSize: 14,
    fontWeight: 600,
    color: '#e11d48',
    background: '#fff1f2',
    padding: '6px 14px',
    borderRadius: 8,
  },
  center: {
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    justifyContent: 'center',
    minHeight: '60vh',
    textAlign: 'center',
  },
  spinner: {
    width: 40,
    height: 40,
    border: '4px solid #e2e8f0',
    borderTop: '4px solid #e11d48',
    borderRadius: '50%',
    animation: 'spin 0.8s linear infinite',
  },
};
