import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import toast from 'react-hot-toast';
import { Link2, ArrowRight, ShieldCheck } from 'lucide-react';

export default function AccessPage() {
  const [token, setToken] = useState('');
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    const t = token.trim();
    if (!t) return toast.error('Please enter your assessment token');
    setLoading(true);
    try {
      await axios.get(`/api/tokens/session/${t}`);
      navigate(`/assessment/${t}`);
    } catch (err) {
      const msg = err.response?.data?.message || 'Invalid or expired token';
      toast.error(msg);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={{
      minHeight: '100vh', background: 'linear-gradient(135deg, #0f172a 0%, #1e1b4b 50%, #0f172a 100%)',
      display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 24,
    }}>
      <div style={{ width: '100%', maxWidth: 460 }}>
        {/* Logo */}
        <div style={{ textAlign: 'center', marginBottom: 40 }}>
          <div style={{
            width: 64, height: 64, borderRadius: 16, background: '#e11d48',
            display: 'flex', alignItems: 'center', justifyContent: 'center', margin: '0 auto 16px',
          }}>
            <ShieldCheck size={32} color="#fff" />
          </div>
          <h1 style={{ fontSize: 28, fontWeight: 800, color: '#fff', letterSpacing: '-0.5px' }}>Assessment Portal</h1>
          <p style={{ color: '#94a3b8', marginTop: 8, fontSize: 15 }}>Use the link sent to your email to begin</p>
        </div>

        {/* Card */}
        <div style={{
          background: 'rgba(255,255,255,0.05)', backdropFilter: 'blur(12px)',
          border: '1px solid rgba(255,255,255,0.1)', borderRadius: 20, padding: 36,
        }}>
          <form onSubmit={handleSubmit}>
            <label style={{ display: 'block', fontSize: 13, fontWeight: 600, color: '#cbd5e1', marginBottom: 8 }}>
              Assessment Token
            </label>
            <div style={{ position: 'relative', marginBottom: 20 }}>
              <Link2 size={16} style={{ position: 'absolute', left: 14, top: '50%', transform: 'translateY(-50%)', color: '#64748b' }} />
              <input
                value={token}
                onChange={e => setToken(e.target.value)}
                placeholder="Paste your token here..."
                autoFocus
                style={{
                  width: '100%', padding: '12px 14px 12px 42px',
                  borderRadius: 10, border: '1px solid rgba(255,255,255,0.15)',
                  background: 'rgba(255,255,255,0.08)', color: '#fff',
                  fontSize: 14, outline: 'none', boxSizing: 'border-box',
                  fontFamily: 'monospace', letterSpacing: '0.05em',
                }}
              />
            </div>
            <button
              type="submit"
              disabled={loading}
              style={{
                width: '100%', padding: '13px', borderRadius: 10,
                background: loading ? '#64748b' : '#e11d48', color: '#fff',
                border: 'none', fontWeight: 700, fontSize: 15, cursor: loading ? 'not-allowed' : 'pointer',
                display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8,
                transition: 'background 0.2s',
              }}
            >
              {loading ? 'Validating...' : <><span>Access Assessment</span><ArrowRight size={18} /></>}
            </button>
          </form>

          <div style={{ marginTop: 24, padding: '14px 16px', background: 'rgba(255,255,255,0.04)', borderRadius: 10, border: '1px solid rgba(255,255,255,0.08)' }}>
            <p style={{ fontSize: 13, color: '#94a3b8', margin: 0, lineHeight: 1.6 }}>
              Your token was sent to your email by the HR team. If you haven't received it, please contact your recruiter.
            </p>
          </div>
        </div>

        <p style={{ textAlign: 'center', color: '#475569', fontSize: 13, marginTop: 24 }}>
          Secure · Timed · Confidential
        </p>
      </div>
    </div>
  );
}
