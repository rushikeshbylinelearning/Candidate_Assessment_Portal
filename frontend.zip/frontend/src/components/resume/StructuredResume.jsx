import React, { useState } from 'react';
import { 
  Mail, Phone, MapPin, Linkedin, Github, Globe, Briefcase, 
  GraduationCap, Code, Award, FolderGit2, Calendar, ChevronDown, 
  ChevronUp, ExternalLink, FileText, Loader
} from 'lucide-react';
import './StructuredResume.css';

export default function StructuredResume({ resumeData, candidate, onViewOriginal }) {
  const [expandedSections, setExpandedSections] = useState({
    experience: true,
    education: true,
    projects: true,
    certifications: true,
  });

  const toggleSection = (section) => {
    setExpandedSections(prev => ({ ...prev, [section]: !prev[section] }));
  };

  if (!resumeData) {
    return (
      <div className="structured-resume-loading">
        <Loader size={32} className="spinner" />
        <p>Loading resume data...</p>
      </div>
    );
  }

  if (resumeData.parsingStatus === 'processing') {
    return (
      <div className="structured-resume-processing">
        <Loader size={40} className="spinner" />
        <h3>Processing Resume...</h3>
        <p>We're extracting and structuring the resume data. This will take a moment.</p>
      </div>
    );
  }

  if (resumeData.parsingStatus === 'failed') {
    return (
      <div className="structured-resume-error">
        <FileText size={48} />
        <h3>Failed to Parse Resume</h3>
        <p>{resumeData.parsingError || 'Unable to extract structured data from resume'}</p>
        {onViewOriginal && (
          <button onClick={onViewOriginal} className="view-original-btn">
            View Original Resume
          </button>
        )}
      </div>
    );
  }

  const { basicInfo, summary, skills, experience, education, projects, certifications, aiInsights } = resumeData;

  return (
    <div className="structured-resume">
      {/* Header - Basic Info */}
      <div className="resume-header">
        <div className="resume-avatar">
          {(basicInfo?.name || candidate?.name || 'U')[0].toUpperCase()}
        </div>
        <div className="resume-header-content">
          <h1 className="resume-name">{basicInfo?.name || candidate?.name}</h1>
          {aiInsights?.primaryRole && (
            <p className="resume-role">{aiInsights.primaryRole}</p>
          )}
          <div className="resume-contact-info">
            {(basicInfo?.email || candidate?.email) && (
              <a href={`mailto:${basicInfo?.email || candidate?.email}`} className="contact-link">
                <Mail size={14} />
                {basicInfo?.email || candidate?.email}
              </a>
            )}
            {(basicInfo?.phone || candidate?.phone) && (
              <span className="contact-item">
                <Phone size={14} />
                {basicInfo?.phone || candidate?.phone}
              </span>
            )}
            {basicInfo?.location && (
              <span className="contact-item">
                <MapPin size={14} />
                {basicInfo.location}
              </span>
            )}
          </div>
          <div className="resume-social-links">
            {basicInfo?.linkedin && (
              <a href={basicInfo.linkedin} target="_blank" rel="noreferrer" className="social-link">
                <Linkedin size={14} />
                LinkedIn
              </a>
            )}
            {basicInfo?.github && (
              <a href={basicInfo.github} target="_blank" rel="noreferrer" className="social-link">
                <Github size={14} />
                GitHub
              </a>
            )}
            {basicInfo?.portfolio && (
              <a href={basicInfo.portfolio} target="_blank" rel="noreferrer" className="social-link">
                <Globe size={14} />
                Portfolio
              </a>
            )}
          </div>
        </div>
        {onViewOriginal && (
          <button onClick={onViewOriginal} className="view-original-link">
            <FileText size={16} />
            View Original
          </button>
        )}
      </div>

      {/* AI Insights Banner */}
      {aiInsights && (
        <div className="ai-insights-banner">
          <div className="insight-item">
            <span className="insight-label">Experience</span>
            <span className="insight-value">{aiInsights.experienceYears} years</span>
          </div>
          <div className="insight-item">
            <span className="insight-label">Level</span>
            <span className="insight-value">{aiInsights.seniorityLevel}</span>
          </div>
          {aiInsights.keyStrengths && aiInsights.keyStrengths.length > 0 && (
            <div className="insight-item">
              <span className="insight-label">Top Skills</span>
              <span className="insight-value">{aiInsights.keyStrengths.slice(0, 3).join(', ')}</span>
            </div>
          )}
        </div>
      )}

      {/* Summary */}
      {summary && (
        <div className="resume-section">
          <h2 className="section-title">Professional Summary</h2>
          <p className="summary-text">{summary}</p>
        </div>
      )}

      {/* Skills */}
      {skills && (skills.technical?.length > 0 || skills.tools?.length > 0) && (
        <div className="resume-section">
          <h2 className="section-title">
            <Code size={18} />
            Skills
          </h2>
          <div className="skills-grid">
            {skills.technical?.length > 0 && (
              <div className="skill-category">
                <h3 className="skill-category-title">Technical Skills</h3>
                <div className="skill-tags">
                  {skills.technical.map((skill, idx) => (
                    <span key={idx} className="skill-tag">{skill}</span>
                  ))}
                </div>
              </div>
            )}
            {skills.tools?.length > 0 && (
              <div className="skill-category">
                <h3 className="skill-category-title">Tools & Technologies</h3>
                <div className="skill-tags">
                  {skills.tools.map((tool, idx) => (
                    <span key={idx} className="skill-tag">{tool}</span>
                  ))}
                </div>
              </div>
            )}
            {skills.languages?.length > 0 && (
              <div className="skill-category">
                <h3 className="skill-category-title">Languages</h3>
                <div className="skill-tags">
                  {skills.languages.map((lang, idx) => (
                    <span key={idx} className="skill-tag">{lang}</span>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Experience */}
      {experience && experience.length > 0 && (
        <div className="resume-section">
          <div className="section-header-collapsible" onClick={() => toggleSection('experience')}>
            <h2 className="section-title">
              <Briefcase size={18} />
              Work Experience
            </h2>
            {expandedSections.experience ? <ChevronUp size={18} /> : <ChevronDown size={18} />}
          </div>
          {expandedSections.experience && (
            <div className="experience-timeline">
              {experience.map((exp, idx) => (
                <div key={idx} className="experience-item">
                  <div className="experience-marker"></div>
                  <div className="experience-content">
                    <div className="experience-header">
                      <div>
                        <h3 className="experience-role">{exp.role}</h3>
                        <p className="experience-company">{exp.company}</p>
                      </div>
                      <div className="experience-meta">
                        {exp.duration && (
                          <span className="experience-duration">
                            <Calendar size={14} />
                            {exp.duration}
                          </span>
                        )}
                        {exp.location && (
                          <span className="experience-location">
                            <MapPin size={14} />
                            {exp.location}
                          </span>
                        )}
                      </div>
                    </div>
                    {exp.responsibilities && exp.responsibilities.length > 0 && (
                      <ul className="experience-responsibilities">
                        {exp.responsibilities.map((resp, i) => (
                          <li key={i}>{resp}</li>
                        ))}
                      </ul>
                    )}
                    {exp.achievements && exp.achievements.length > 0 && (
                      <div className="experience-achievements">
                        <strong>Key Achievements:</strong>
                        <ul>
                          {exp.achievements.map((ach, i) => (
                            <li key={i}>{ach}</li>
                          ))}
                        </ul>
                      </div>
                    )}
                    {exp.technologies && exp.technologies.length > 0 && (
                      <div className="experience-tech">
                        {exp.technologies.map((tech, i) => (
                          <span key={i} className="tech-tag">{tech}</span>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Education */}
      {education && education.length > 0 && (
        <div className="resume-section">
          <div className="section-header-collapsible" onClick={() => toggleSection('education')}>
            <h2 className="section-title">
              <GraduationCap size={18} />
              Education
            </h2>
            {expandedSections.education ? <ChevronUp size={18} /> : <ChevronDown size={18} />}
          </div>
          {expandedSections.education && (
            <div className="education-list">
              {education.map((edu, idx) => (
                <div key={idx} className="education-item">
                  <div className="education-icon">
                    <GraduationCap size={20} />
                  </div>
                  <div className="education-content">
                    <h3 className="education-degree">{edu.degree}</h3>
                    <p className="education-institution">{edu.institution}</p>
                    <div className="education-meta">
                      {edu.year && <span>{edu.year}</span>}
                      {edu.location && <span>• {edu.location}</span>}
                      {edu.gpa && <span>• GPA: {edu.gpa}</span>}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Projects */}
      {projects && projects.length > 0 && (
        <div className="resume-section">
          <div className="section-header-collapsible" onClick={() => toggleSection('projects')}>
            <h2 className="section-title">
              <FolderGit2 size={18} />
              Projects
            </h2>
            {expandedSections.projects ? <ChevronUp size={18} /> : <ChevronDown size={18} />}
          </div>
          {expandedSections.projects && (
            <div className="projects-grid">
              {projects.map((project, idx) => (
                <div key={idx} className="project-card">
                  <div className="project-header">
                    <h3 className="project-name">{project.name}</h3>
                    {project.link && (
                      <a href={project.link} target="_blank" rel="noreferrer" className="project-link">
                        <ExternalLink size={14} />
                      </a>
                    )}
                  </div>
                  <p className="project-description">{project.description}</p>
                  {project.technologies && project.technologies.length > 0 && (
                    <div className="project-tech">
                      {project.technologies.map((tech, i) => (
                        <span key={i} className="tech-tag">{tech}</span>
                      ))}
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Certifications */}
      {certifications && certifications.length > 0 && (
        <div className="resume-section">
          <div className="section-header-collapsible" onClick={() => toggleSection('certifications')}>
            <h2 className="section-title">
              <Award size={18} />
              Certifications
            </h2>
            {expandedSections.certifications ? <ChevronUp size={18} /> : <ChevronDown size={18} />}
          </div>
          {expandedSections.certifications && (
            <div className="certifications-list">
              {certifications.map((cert, idx) => (
                <div key={idx} className="certification-item">
                  <Award size={16} />
                  <div className="certification-content">
                    <h3 className="certification-name">{cert.name}</h3>
                    <p className="certification-issuer">{cert.issuer}</p>
                    {cert.date && <span className="certification-date">{cert.date}</span>}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
}
