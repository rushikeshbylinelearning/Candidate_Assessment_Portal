import React from 'react';
import { Target, CheckCircle2, XCircle, TrendingUp } from 'lucide-react';
import './RoleMatchCard.css';

export default function RoleMatchCard({ matchData }) {
  if (!matchData) return null;

  const { matchPercentage, matchedSkills, missingSkills } = matchData;

  const getMatchColor = (percentage) => {
    if (percentage >= 80) return '#22c55e';
    if (percentage >= 60) return '#f59e0b';
    return '#ef4444';
  };

  const getMatchLabel = (percentage) => {
    if (percentage >= 80) return 'Excellent Match';
    if (percentage >= 60) return 'Good Match';
    if (percentage >= 40) return 'Moderate Match';
    return 'Low Match';
  };

  return (
    <div className="role-match-card">
      <div className="match-header">
        <div className="match-icon">
          <Target size={20} />
        </div>
        <h3 className="match-title">Role Match Analysis</h3>
      </div>

      <div className="match-score-section">
        <div 
          className="match-score-circle"
          style={{ 
            background: `conic-gradient(${getMatchColor(matchPercentage)} ${matchPercentage * 3.6}deg, #e2e8f0 0deg)` 
          }}
        >
          <div className="match-score-inner">
            <span className="match-percentage">{matchPercentage}%</span>
            <span className="match-label">{getMatchLabel(matchPercentage)}</span>
          </div>
        </div>
      </div>

      {matchedSkills && matchedSkills.length > 0 && (
        <div className="match-section">
          <div className="match-section-header">
            <CheckCircle2 size={16} />
            <h4>Matched Skills ({matchedSkills.length})</h4>
          </div>
          <div className="skill-tags">
            {matchedSkills.map((skill, idx) => (
              <span key={idx} className="skill-tag matched">{skill}</span>
            ))}
          </div>
        </div>
      )}

      {missingSkills && missingSkills.length > 0 && (
        <div className="match-section">
          <div className="match-section-header">
            <XCircle size={16} />
            <h4>Missing Skills ({missingSkills.length})</h4>
          </div>
          <div className="skill-tags">
            {missingSkills.map((skill, idx) => (
              <span key={idx} className="skill-tag missing">{skill}</span>
            ))}
          </div>
        </div>
      )}

      <div className="match-recommendation">
        <TrendingUp size={16} />
        <p>
          {matchPercentage >= 80 
            ? 'Strong candidate for this role. Proceed with interview.'
            : matchPercentage >= 60
            ? 'Good fit with some skill gaps. Consider for interview.'
            : 'Significant skill gaps. May need additional training.'}
        </p>
      </div>
    </div>
  );
}
