/**
 * Test script for Workflow API integration
 * Run with: node src/modules/workflow/test-workflow-api.js
 */

const axios = require('axios');

const WORKFLOW_API_BASE = 'https://workflow.legatolxp.online/api';
const WORKFLOW_API_KEY = 'wf_cd1877f2e29fb6abb3d50039bbba7f19eda27002a4fa373fda4f325b';
const WORKFLOW_CREDENTIALS = {
  email: 'info@bylinelearning.com',
  password: 'admin@byline25',
};

const workflowApi = axios.create({
  baseURL: WORKFLOW_API_BASE,
  headers: {
    'Authorization': `Bearer ${WORKFLOW_API_KEY}`,
    'Content-Type': 'application/json',
  },
});

async function testWorkflowAPI() {
  console.log('🔍 Testing Workflow API Integration...\n');

  try {
    // Test 1: Check health
    console.log('1️⃣ API Health Check...');
    const healthResponse = await workflowApi.get('/health');
    console.log('✅ API is healthy');
    console.log('   Status:', healthResponse.data.status);
    console.log('   Database:', healthResponse.data.database);
    console.log('');

    // Test 2: Try workflow-specific endpoints
    console.log('2️⃣ Testing Workflow Endpoints...');
    const workflowEndpoints = [
      '/workflows',
      '/workflow',
      '/tasks',
      '/task',
      '/candidates',
      '/candidate',
      '/reports',
      '/report',
      '/dashboard',
      '/stats',
      '/statistics',
      '/metrics'
    ];
    
    for (const endpoint of workflowEndpoints) {
      try {
        console.log(`   Trying GET ${endpoint}...`);
        const response = await workflowApi.get(endpoint);
        console.log(`   ✅ Success at ${endpoint}`);
        console.log('   Response:', JSON.stringify(response.data, null, 2).substring(0, 500));
        console.log('');
      } catch (error) {
        console.log(`   ❌ ${endpoint}: ${error.response?.status || error.message}`);
      }
    }

    // Test 3: Try authentication with different credentials format
    console.log('3️⃣ Testing Authentication...');
    const authEndpoints = [
      { path: '/login', body: WORKFLOW_CREDENTIALS },
      { path: '/login', body: { username: WORKFLOW_CREDENTIALS.email, password: WORKFLOW_CREDENTIALS.password } },
      { path: '/signin', body: WORKFLOW_CREDENTIALS },
      { path: '/api-key/validate', body: { apiKey: WORKFLOW_API_KEY } }
    ];
    
    for (const { path, body } of authEndpoints) {
      try {
        console.log(`   Trying POST ${path}...`);
        const response = await workflowApi.post(path, body);
        console.log(`   ✅ Success at ${path}`);
        console.log('   Response:', JSON.stringify(response.data, null, 2));
        console.log('');
        break;
      } catch (error) {
        console.log(`   ❌ ${path}: ${error.response?.status || error.message}`);
      }
    }

    console.log('✨ Workflow API testing completed!');
    console.log('\n📝 Note: The workflow API may require different endpoints than expected.');
    console.log('   Please check the workflow API documentation for correct endpoint paths.');

  } catch (error) {
    console.error('❌ Test failed:', error.response?.data || error.message);
  }
}

// Run the test
testWorkflowAPI();
