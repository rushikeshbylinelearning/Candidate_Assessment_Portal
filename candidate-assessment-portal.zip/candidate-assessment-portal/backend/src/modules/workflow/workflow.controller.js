const axios = require('axios');

const WORKFLOW_API_BASE = 'https://workflow.legatolxp.online/api';
const WORKFLOW_API_KEY = 'wf_cd1877f2e29fb6abb3d50039bbba7f19eda27002a4fa373fda4f325b';
const WORKFLOW_CREDENTIALS = {
  email: 'info@bylinelearning.com',
  password: 'admin@byline25',
};

// Create axios instance for workflow API
const workflowApi = axios.create({
  baseURL: WORKFLOW_API_BASE,
  headers: {
    'Authorization': `Bearer ${WORKFLOW_API_KEY}`,
    'Content-Type': 'application/json',
  },
});

// Authenticate and get token
const authenticateWorkflow = async () => {
  try {
    const response = await workflowApi.post('/auth/login', WORKFLOW_CREDENTIALS);
    return response.data.token || response.data.accessToken;
  } catch (error) {
    console.error('Workflow authentication failed:', error.response?.data || error.message);
    throw new Error('Failed to authenticate with workflow API');
  }
};

// Get workflow analytics overview
exports.getWorkflowOverview = async (req, res) => {
  try {
    const token = await authenticateWorkflow();
    workflowApi.defaults.headers.common['Authorization'] = `Bearer ${token}`;
    
    const response = await workflowApi.get('/analytics/overview');
    res.json(response.data);
  } catch (error) {
    console.error('Failed to fetch workflow overview:', error.message);
    res.status(500).json({ 
      error: 'Failed to fetch workflow overview',
      message: error.message 
    });
  }
};

// Get workflow funnel data
exports.getWorkflowFunnel = async (req, res) => {
  try {
    const token = await authenticateWorkflow();
    workflowApi.defaults.headers.common['Authorization'] = `Bearer ${token}`;
    
    const response = await workflowApi.get('/analytics/funnel');
    res.json(response.data);
  } catch (error) {
    console.error('Failed to fetch workflow funnel:', error.message);
    res.status(500).json({ 
      error: 'Failed to fetch workflow funnel',
      message: error.message 
    });
  }
};

// Get workflow performance data
exports.getWorkflowPerformance = async (req, res) => {
  try {
    const token = await authenticateWorkflow();
    workflowApi.defaults.headers.common['Authorization'] = `Bearer ${token}`;
    
    const response = await workflowApi.get('/analytics/performance');
    res.json(response.data);
  } catch (error) {
    console.error('Failed to fetch workflow performance:', error.message);
    res.status(500).json({ 
      error: 'Failed to fetch workflow performance',
      message: error.message 
    });
  }
};

// Get all workflow analytics data
exports.getAllWorkflowData = async (req, res) => {
  try {
    const token = await authenticateWorkflow();
    workflowApi.defaults.headers.common['Authorization'] = `Bearer ${token}`;
    
    const [overview, funnel, performance] = await Promise.allSettled([
      workflowApi.get('/analytics/overview'),
      workflowApi.get('/analytics/funnel'),
      workflowApi.get('/analytics/performance'),
    ]);

    res.json({
      overview: overview.status === 'fulfilled' ? overview.value.data : null,
      funnel: funnel.status === 'fulfilled' ? funnel.value.data : [],
      performance: performance.status === 'fulfilled' ? performance.value.data : null,
      errors: {
        overview: overview.status === 'rejected' ? overview.reason.message : null,
        funnel: funnel.status === 'rejected' ? funnel.reason.message : null,
        performance: performance.status === 'rejected' ? performance.reason.message : null,
      },
    });
  } catch (error) {
    console.error('Failed to fetch workflow data:', error.message);
    res.status(500).json({ 
      error: 'Failed to fetch workflow data',
      message: error.message 
    });
  }
};

// Get workflow analytics (generic endpoint)
exports.getWorkflowAnalytics = async (req, res) => {
  try {
    const token = await authenticateWorkflow();
    workflowApi.defaults.headers.common['Authorization'] = `Bearer ${token}`;
    
    const response = await workflowApi.get('/analytics');
    res.json(response.data);
  } catch (error) {
    console.error('Failed to fetch workflow analytics:', error.message);
    res.status(500).json({ 
      error: 'Failed to fetch workflow analytics',
      message: error.message 
    });
  }
};
