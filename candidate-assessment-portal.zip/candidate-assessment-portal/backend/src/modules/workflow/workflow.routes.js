const router = require('express').Router();
const ctrl = require('./workflow.controller');
const { protect } = require('../../middleware/auth');

// Protect all workflow routes
router.use(protect);

// Workflow analytics endpoints
router.get('/analytics', ctrl.getWorkflowAnalytics);
router.get('/analytics/overview', ctrl.getWorkflowOverview);
router.get('/analytics/funnel', ctrl.getWorkflowFunnel);
router.get('/analytics/performance', ctrl.getWorkflowPerformance);
router.get('/analytics/all', ctrl.getAllWorkflowData);

module.exports = router;
